% Assignment 4
% Riley Densley
% A01227345

function [thres] = threshold(nV)
%UNTITLED7 Summary of this function goes here
%   Detailed explanation goes here

thres = nV * sqrt(2 * log(3));

end

