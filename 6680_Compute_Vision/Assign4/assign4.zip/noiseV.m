% Assignment 4
% Riley Densley
% A01227345

function [nV] = noiseV(H, V, D)
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here

subband = cat(3, V, H, D);

% size(nV)


nV = sqrt(median(abs(subband), 'all')/0.6745);


%  size(nV)
end

